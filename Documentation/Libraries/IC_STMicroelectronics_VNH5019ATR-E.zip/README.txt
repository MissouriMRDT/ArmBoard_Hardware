
EE Concierge + KiCAD Library Install Instruction:
Contents of this Zip file:
- eec.lib: The schematic symbol(s)
- eec.dcm: The component description, keywords, and aliases
- eec.pretty/*.mod: The layout footprint(s)
- eec.models/*.step: The 3d models of the components

The schematic symbols are organized by the manufacturer part number.
The layout footprints are organized by the manufacturer name and the
identifier the manufacturer gives to the footprint, or the part number if one
is not supplied.

All parts exported successfully.
